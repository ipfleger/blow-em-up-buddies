// public/lobby.js
window.socket = io();
window.myId = null;
window.currentRoomCode = "----";

window.socket.on('connect', () => { window.myId = window.socket.id; });

function getValidName() {
    const name = document.getElementById('input-name').value.trim().toUpperCase();
    if (!name) { alert("Please enter a callsign to join!"); return null; }
    return name;
}

document.getElementById('btn-host').onclick = () => {
    let name = getValidName();
    if (name) window.socket.emit('host-game', name);
};

document.getElementById('btn-join').onclick = () => {
    let name = getValidName();
    if (name) {
        const code = document.getElementById('input-code').value.trim().toUpperCase();
        if (code.length === 4) window.socket.emit('join-game', { code: code, name: name });
    }
};

window.socket.on('room-error', (msg) => alert(msg));

window.socket.on('room-joined', (data) => {
    document.getElementById('start-screen').style.display = 'none';
    document.getElementById('lobby-screen').style.display = 'flex'; 
    document.getElementById('lobby-code-display').innerText = data.code;
    window.currentRoomCode = data.code;
    
    if (data.isHost) document.getElementById('btn-start-match').style.display = 'block';
});

['tank1_driver', 'tank1_gunner', 'tank2_driver', 'tank2_gunner'].forEach(slotId => {
    const btn = document.getElementById('slot-' + slotId);
    if (btn) btn.onclick = () => window.socket.emit('change-slot', slotId);
});

document.getElementById('btn-global-settings').onclick = () => { document.getElementById('settings-modal').style.display = 'block'; };
document.getElementById('btn-ready-up').onclick = () => window.socket.emit('toggle-ready');

function switchFlowStep(stepId) {
    document.querySelectorAll('.flow-step').forEach(step => step.classList.remove('active-step'));
    document.getElementById(stepId).classList.add('active-step');
}
document.getElementById('btn-next-garage').onclick = () => switchFlowStep('step-garage');
document.getElementById('btn-next-mission').onclick = () => switchFlowStep('step-mission');

window.socket.on('lobby-update', (lobby) => {
    let mySlot = null;
    let allReady = true;
    let assignedCount = 0;

    if (lobby.icons && lobby.icons.team1 && lobby.icons.team2) {
        document.getElementById('icon-team1').innerHTML = `<img src="/icons/${lobby.icons.team1}" style="width: 24px; height: 24px; vertical-align: middle; filter: invert(86%) sepia(21%) saturate(795%) hue-rotate(33deg) brightness(101%) contrast(87%);">`;
        document.getElementById('icon-team2').innerHTML = `<img src="/icons/${lobby.icons.team2}" style="width: 24px; height: 24px; vertical-align: middle; filter: invert(36%) sepia(93%) saturate(3015%) hue-rotate(325deg) brightness(101%) contrast(106%);">`;
    }

    document.querySelectorAll('.slot-btn').forEach(btn => {
        let roleName = btn.id.split('_')[1].toUpperCase();
        btn.innerText = `${roleName}: [ OPEN ]`;
        btn.className = "slot-btn";
    });
    
    for (let slot in lobby.slots) {
        if (lobby.slots[slot]) {
            assignedCount++;
            let btn = document.getElementById(`slot-${slot}`);
            let roleName = slot.split('_')[1].toUpperCase();
            let socketId = lobby.slots[slot];
            let playerName = lobby.names ? (lobby.names[socketId] || "PLAYER") : "PLAYER";
            
            let isReady = lobby.ready && lobby.ready[socketId];
            if (!isReady) allReady = false;

            btn.innerText = `${roleName}: ${playerName} ${isReady ? '✅' : '❌'}`;
            btn.classList.add('occupied');
            
            if (socketId === window.myId) {
                btn.classList.add('my-slot');
                mySlot = slot;
                window.myTankId = slot.split('_')[0]; 
                window.myRole = slot.split('_')[1];
            }
        }
    }

    if (assignedCount === 0) allReady = false;

    const startBtn = document.getElementById('btn-start-match');
    if (startBtn) {
        startBtn.onclick = null; 
        if (allReady && assignedCount > 0) {
            startBtn.innerText = 'LAUNCH MATCH 🚀';
            startBtn.style.background = '#d44a8e';
            startBtn.onclick = () => window.socket.emit('start-match');
        } else {
            startBtn.innerText = 'NUDGE UNREADY ⚠️';
            startBtn.style.background = '#ff8c00';
            startBtn.onclick = () => window.socket.emit('nudge-unready');
        }
    }

    const readyBtn = document.getElementById('btn-ready-up');
    if (readyBtn) {
        if (lobby.ready && lobby.ready[window.myId]) {
            readyBtn.innerText = 'READY ✅';
            readyBtn.style.background = '#6dcbc3'; readyBtn.style.color = '#1f1c30';
        } else {
            readyBtn.innerText = 'I AM READY';
            readyBtn.style.background = '#b4d455'; readyBtn.style.color = '#1f1c30';
        }
    }

    const nextBtn = document.getElementById('btn-next-garage');
    if (mySlot) {
        nextBtn.style.display = 'flex';
        let isDriver = mySlot.includes('driver');
        document.getElementById('ui-driver').style.display = isDriver ? 'block' : 'none';
        document.getElementById('ui-gunner').style.display = !isDriver ? 'block' : 'none';
    } else {
        nextBtn.style.display = 'none';
        switchFlowStep('step-roster'); 
    }
});

window.socket.on('receive-nudge', () => {
    const readyBtn = document.getElementById('btn-ready-up');
    if(readyBtn) {
        readyBtn.style.transform = 'scale(1.1)';
        readyBtn.style.boxShadow = '0 0 20px red';
        setTimeout(() => { readyBtn.style.transform = 'scale(1.0)'; readyBtn.style.boxShadow = 'none'; }, 500);
    }
});