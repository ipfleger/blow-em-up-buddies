// public/tank-factory.js
window.TankFactory = {
    
    // The beautiful cel-shaded toon texture from blu.html
    createEntityTexture: function(hexColorStr) {
        const canvas = document.createElement('canvas');
        canvas.width = 256; canvas.height = 256;
        const ctx = canvas.getContext('2d');

        ctx.fillStyle = hexColorStr;
        ctx.fillRect(0, 0, 256, 256);

        // Baked "Toon" Lighting
        const lightGrad = ctx.createLinearGradient(0, 0, 0, 256);
        lightGrad.addColorStop(0, 'rgba(255, 255, 255, 0.3)');
        lightGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0)');
        lightGrad.addColorStop(1, 'rgba(0, 0, 0, 0.5)');
        ctx.fillStyle = lightGrad;
        ctx.fillRect(0, 0, 256, 256);

        // Tech Panel Lines (Used for visual detail AND 3D bumping)
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.6)';
        ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.beginPath();
        ctx.moveTo(40, 40); ctx.lineTo(216, 40); ctx.lineTo(216, 120); 
        ctx.moveTo(40, 216); ctx.lineTo(120, 216); 
        ctx.moveTo(160, 160); ctx.lineTo(190, 160); ctx.lineTo(190, 190); 
        ctx.stroke();

        // Comic Halftone Dots
        ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
        for(let x = 12; x < 256; x += 16) {
            for(let y = 12; y < 256; y += 16) {
                ctx.beginPath(); ctx.arc(x, y, 2.5, 0, Math.PI*2); ctx.fill();
            }
        }
        return new THREE.CanvasTexture(canvas);
    },

    // The curated parts dictionary
    PARTS: {
        chassis: [
            { name: "Standard Box", build: (mat) => new THREE.Mesh(new THREE.BoxGeometry(4, 1.5, 6), mat) },
            { name: "Speed Wedge", build: (mat) => {
                const geo = new THREE.BoxGeometry(4, 1.5, 6); const pos = geo.attributes.position;
                for(let i=0; i<pos.count; i++) if(pos.getY(i)>0 && pos.getZ(i)<0) pos.setY(i, -0.5);
                geo.computeVertexNormals(); return new THREE.Mesh(geo, mat);
            }}
        ],
        treads: [
            { name: "Tracks", isHover: false, build: (mat) => {
                const g = new THREE.Group(); const tGeo = new THREE.BoxGeometry(1.2, 1.4, 7);
                const tl = new THREE.Mesh(tGeo, mat); tl.position.set(-2.4, 0, 0);
                const tr = new THREE.Mesh(tGeo, mat); tr.position.set(2.4, 0, 0);
                g.add(tl, tr); return g;
            }},
            { name: "Hover Pods", isHover: true, build: (mat) => {
                const g = new THREE.Group(); const pGeo = new THREE.CylinderGeometry(1.2, 0.8, 0.6, 8);
                const rMat = new THREE.MeshBasicMaterial({color: 0x6dcbc3});
                [[-2.5,-0.2,-2.5], [2.5,-0.2,-2.5], [-2.5,-0.2,2.5], [2.5,-0.2,2.5]].forEach(p => {
                    const pod = new THREE.Mesh(pGeo, mat); pod.position.set(...p);
                    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.8, 0.15, 8, 16), rMat);
                    ring.rotateX(Math.PI/2); ring.position.set(p[0], p[1]-0.4, p[2]);
                    g.add(pod, ring);
                }); return g;
            }}
        ],
        turret: [
            { name: "Dome", build: (mat) => new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.8, 1.2, 8), mat) },
            { name: "Blockhead", build: (mat) => new THREE.Mesh(new THREE.BoxGeometry(2.5, 1.2, 3.0), mat) }
        ],
        barrel: [
            { name: "Cannon", build: (mat) => {
                const b = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.4, 4, 8), mat);
                b.rotation.x = Math.PI / 2; b.position.set(0, 0, -2.5); return b;
            }},
            { name: "Twin-Link", build: (mat) => {
                const g = new THREE.Group(); const bGeo = new THREE.CylinderGeometry(0.2, 0.25, 3.5, 8); bGeo.rotateX(Math.PI/2);
                const b1 = new THREE.Mesh(bGeo, mat); b1.position.set(-0.5, 0, -2.0);
                const b2 = new THREE.Mesh(bGeo, mat); b2.position.set(0.5, 0, -2.0);
                g.add(b1, b2); return g;
            }}
        ]
    },

    createTank: function(sp, sceneGroup) {
        const group = new THREE.Group();
        
        let chIdx = sp.chassis || 0;
        let trIdx = sp.treads || 0;
        let tuIdx = sp.turret || 0;
        let baIdx = sp.barrel || 0;

        let colorMain = typeof sp.c1 === 'number' ? '#' + sp.c1.toString(16).padStart(6, '0') : (sp.c1 || '#b4d455');
        let colorAccent = typeof sp.c2 === 'number' ? '#' + sp.c2.toString(16).padStart(6, '0') : (sp.c2 || '#ff3366');
        let colorDark = '#1a1922';

        let texMain = this.createEntityTexture(colorMain);
        let texAccent = this.createEntityTexture(colorAccent);
        let texDark = this.createEntityTexture(colorDark);

        let matMain = new THREE.MeshStandardMaterial({ map: texMain, bumpMap: texMain, bumpScale: 0.08, roughness: 0.4 });
        let matAccent = new THREE.MeshStandardMaterial({ map: texAccent, bumpMap: texAccent, bumpScale: 0.08, roughness: 0.4 });
        let matTread = new THREE.MeshStandardMaterial({ map: texDark, bumpMap: texDark, bumpScale: 0.05, roughness: 0.9 });

        const hullGroup = new THREE.Group();
        const isHover = this.PARTS.treads[trIdx].isHover;
        const yOffset = isHover ? 1.2 : 0.8; 

        const chassisMesh = this.PARTS.chassis[chIdx].build(matMain);
        chassisMesh.position.y = yOffset;
        
        const treadsMesh = this.PARTS.treads[trIdx].build(matTread);
        treadsMesh.position.y = yOffset;

        hullGroup.add(chassisMesh, treadsMesh);
        group.add(hullGroup);

        const turretGroup = new THREE.Group();
        const pitchGroup = new THREE.Group(); 
        
        const turretMesh = this.PARTS.turret[tuIdx].build(matAccent);
        turretGroup.add(turretMesh);

        const barrelMesh = this.PARTS.barrel[baIdx].build(matAccent);
        pitchGroup.add(barrelMesh);
        
        turretGroup.add(pitchGroup);
        
        sceneGroup.add(group); 
        sceneGroup.add(turretGroup); 
        
        group.turretRef = turretGroup; 
        group.pitchRef = pitchGroup; 
        
        return group;
    }
};