// game-engine.js
const THREE = require('three');
const { ServerTank } = require('./driver');
const { getTerrainHeight } = require('./maps'); 

class Match {
    constructor(roomId, configs) {
        this.roomId = roomId;
        this.tanks = {
            'tank1': new ServerTank('tank1', configs ? configs.tank1 : { chassis:0, treads:0, turret:0, barrel:0, c1:'#b4d455', c2:'#ff3366' }),
            'tank2': new ServerTank('tank2', configs ? configs.tank2 : { chassis:0, treads:0, turret:0, barrel:0, c1:'#6dcbc3', c2:'#d44a8e' })
        };
        this.playerMapping = {}; 
        
        this.bullets = [];
        this.bombs = [];
        this.explosions = []; 
        this.hits = []; 
    }

    assignPlayer(socketId, tankId, role) {
        this.playerMapping[socketId] = { tankId, role };
        if (role === 'driver') this.tanks[tankId].driverId = socketId;
        if (role === 'gunner') this.tanks[tankId].gunnerId = socketId;
    }

    removePlayer(socketId) {
        const mapping = this.playerMapping[socketId];
        if (mapping) {
            const tank = this.tanks[mapping.tankId];
            if (mapping.role === 'driver') tank.driverId = null;
            if (mapping.role === 'gunner') tank.gunnerId = null;
            delete this.playerMapping[socketId];
        }
    }

    applyInput(socketId, input) { 
        const mapping = this.playerMapping[socketId];
        if (mapping && this.tanks[mapping.tankId]) {
            const tank = this.tanks[mapping.tankId];
            if (mapping.role === 'driver') {
                tank.driverInputs.moveX = input.moveX;
                tank.driverInputs.moveY = input.moveY;
                tank.driverInputs.isBoosting = input.isBoosting;
                if (input.triggerJump) tank.driverInputs.triggerJump = true;
            } else if (mapping.role === 'gunner') {
                tank.gunnerInputs.aimYaw = input.aimYaw;
                tank.gunnerInputs.aimPitch = input.aimPitch;
                tank.gunnerInputs.isFiring = input.isFiring;
                if (input.triggerSecondary) tank.gunnerInputs.triggerSecondary = true; 
            }
        }
    }

    swapSeats(tankId) {
        const tank = this.tanks[tankId];
        const oldDriver = tank.driverId; const oldGunner = tank.gunnerId;
        tank.driverId = oldGunner; tank.gunnerId = oldDriver;
        if (oldGunner) this.playerMapping[oldGunner].role = 'driver';
        if (oldDriver) this.playerMapping[oldDriver].role = 'gunner';
    }

    tick(delta) {
        const state = { tanks: {}, assignments: this.playerMapping };
        const tankIds = Object.keys(this.tanks);
        
        this.explosions = [];
        this.hits = [];

        for (let id of tankIds) {
            let t = this.tanks[id];
            t.update(delta, this.tanks);

            let barrelBaseY = t.position.y + 2.2;
            let cameraY = t.position.y + 3.4;

            if (t.fireReady) {
                let spreadYaw = (Math.random() - 0.5) * 0.05; let spreadPitch = (Math.random() - 0.5) * 0.05;
                let absYaw = t.turretYaw + spreadYaw; 
                let absPitch = t.turretPitch + spreadPitch;
                
                let camDirX = -Math.sin(absYaw) * Math.cos(absPitch); 
                let camDirY = Math.sin(absPitch); 
                let camDirZ = -Math.cos(absYaw) * Math.cos(absPitch);
                
                let targetX = t.position.x + (camDirX * 40);
                let targetY = cameraY + (camDirY * 40); 
                let targetZ = t.position.z + (camDirZ * 40);

                let aimVecX = targetX - t.position.x;
                let aimVecY = targetY - barrelBaseY;
                let aimVecZ = targetZ - t.position.z;
                let dist = Math.hypot(aimVecX, aimVecY, aimVecZ);
                
                let dX = aimVecX / dist; let dY = aimVecY / dist; let dZ = aimVecZ / dist;
                this.bullets.push({ owner: id, x: t.position.x + dX*4.5, y: barrelBaseY + dY*4.5, z: t.position.z + dZ*4.5, dx: dX, dy: dY, dz: dZ, life: 1.5 });
            }
            
            if (t.bombReady) {
                let absYaw = t.turretYaw; let absPitch = t.turretPitch; 
                
                let camDirX = -Math.sin(absYaw) * Math.cos(absPitch); 
                let camDirY = Math.sin(absPitch);  
                let camDirZ = -Math.cos(absYaw) * Math.cos(absPitch);

                let targetX = t.position.x + (camDirX * 40);
                let targetY = cameraY + (camDirY * 40); 
                let targetZ = t.position.z + (camDirZ * 40);

                let aimVecX = targetX - t.position.x;
                let aimVecY = targetY - barrelBaseY;
                let aimVecZ = targetZ - t.position.z;
                let dist = Math.hypot(aimVecX, aimVecY, aimVecZ);
                
                let dX = aimVecX / dist; let dY = aimVecY / dist; let dZ = aimVecZ / dist;
                this.bombs.push({ owner: id, x: t.position.x + dX*4.5, y: barrelBaseY + dY*4.5, z: t.position.z + dZ*4.5, vx: dX*45, vy: dY*45, vz: dZ*45, age: 0, exploded: false });
            }
        }

        for (let i = this.bullets.length - 1; i >= 0; i--) {
            let b = this.bullets[i];
            b.x += b.dx * 120 * delta; b.y += b.dy * 120 * delta; b.z += b.dz * 120 * delta; b.life -= delta;
            let hit = false;
            for (let j = this.bombs.length - 1; j >= 0; j--) {
                let r = this.bombs[j];
                if (!r.exploded && Math.hypot(b.x - r.x, b.y - r.y, b.z - r.z) < 2.5) { r.exploded = true; hit = true; break; }
            }
            if (!hit) {
                for (let tId in this.tanks) {
                    if (tId !== b.owner && !this.tanks[tId].isDead) {
                        let target = this.tanks[tId];
                        if (Math.hypot(b.x - target.position.x, b.z - target.position.z) < 3.0 && Math.abs(b.y - target.position.y) < 3.0) {
                            target.health -= 5;
                            this.hits.push({ x: b.x, y: b.y, z: b.z, owner: b.owner });
                            if (target.health <= 0) target.die();
                            hit = true; break;
                        }
                    }
                }
            }
            if (!hit && b.y <= getTerrainHeight(b.x, b.z)) hit = true;
            if (hit || b.life <= 0) this.bullets.splice(i, 1);
        }

        for (let i = this.bombs.length - 1; i >= 0; i--) {
            let b = this.bombs[i];
            b.age += delta;

            // --- HOMING MISSILE LOGIC ---
            if (!b.exploded && b.age > 0.25) { 
                let bestTarget = null; let minDist = 80; 
                let bPos = new THREE.Vector3(b.x, b.y, b.z);
                let bVel = new THREE.Vector3(b.vx, b.vy, b.vz);
                let speed = bVel.length();
                let bDir = bVel.clone().normalize();

                for (let tId in this.tanks) {
                    if (tId === b.owner || this.tanks[tId].isDead) continue;
                    let tPos = new THREE.Vector3(this.tanks[tId].position.x, this.tanks[tId].position.y + 1.5, this.tanks[tId].position.z);
                    let toTarget = tPos.clone().sub(bPos);
                    let dist = toTarget.length();
                    let dot = bDir.dot(toTarget.clone().normalize());

                    // Heat-seek only if target is generally in front of the missile
                    if (dist < minDist && dot > 0.4) {
                        minDist = dist; bestTarget = tPos;
                    }
                }

                if (bestTarget) {
                    let desiredDir = bestTarget.sub(bPos).normalize();
                    bDir.lerp(desiredDir, 4.0 * delta).normalize(); 
                    b.vx = bDir.x * speed; b.vy = bDir.y * speed; b.vz = bDir.z * speed;
                }
            }
            // ----------------------------

            b.x += b.vx * delta; b.y += b.vy * delta; b.z += b.vz * delta;

            let hit = b.exploded; let groundY = getTerrainHeight(b.x, b.z);
            if (b.y <= groundY && b.age > 0.05) { b.y = groundY; hit = true; }
            else if (!hit) {
                for (let tId in this.tanks) {
                    if (tId !== b.owner && !this.tanks[tId].isDead) {
                        let target = this.tanks[tId];
                        if (Math.hypot(b.x - target.position.x, b.z - target.position.z) < 3.0 && Math.abs(b.y - target.position.y) < 3.0) { hit = true; break; }
                    }
                }
            }

            if (hit) {
                this.explosions.push({ x: Number(b.x.toFixed(1)), y: Number(b.y.toFixed(1)), z: Number(b.z.toFixed(1)) });
                for (let tId in this.tanks) {
                    let target = this.tanks[tId];
                    if (!target.isDead) {
                        let dist = Math.hypot(b.x - target.position.x, b.y - target.position.y, b.z - target.position.z);
                        if (dist < 25) {
                            let intensity = 1 - (dist / 25);
                            target.health -= 40 * intensity;
                            if (target.health <= 0) target.die();
                            let kx = target.position.x - b.x; let kz = target.position.z - b.z;
                            let kDist = Math.hypot(kx, kz) || 1;
                            target.velocity.x += (kx/kDist) * 1.5 * intensity; target.velocity.z += (kz/kDist) * 1.5 * intensity; target.velocity.y += 0.8 * intensity;
                            target.isGrounded = false;
                        }
                    }
                }
                this.bombs.splice(i, 1);
            }
        }

        for (let i = 0; i < tankIds.length; i++) {
            for (let j = i + 1; j < tankIds.length; j++) {
                let p1 = this.tanks[tankIds[i]]; let p2 = this.tanks[tankIds[j]];
                if (p1.isDead || p2.isDead) continue;
                let dx = p1.position.x - p2.position.x; let dz = p1.position.z - p2.position.z; let dy = p1.position.y - p2.position.y;
                let dist = Math.hypot(dx, dz);
                if (dist < 4.0 && Math.abs(dy) < 3.0) {
                    if (dist === 0) { dx = 1; dz = 0; dist = 1; }
                    let push = (4.0 - dist) * 0.5; let normX = dx / dist; let normZ = dz / dist;
                    p1.position.x += normX * push; p1.position.z += normZ * push;
                    p2.position.x -= normX * push; p2.position.z -= normZ * push;
                    let p1Ramming = p1.driverInputs.isBoosting && Math.abs(p1.currentSpeed) > 60;
                    let p2Ramming = p2.driverInputs.isBoosting && Math.abs(p2.currentSpeed) > 60;
                    if (p1Ramming || p2Ramming) {
                        let f1X = -Math.sin(p1.hullRotation); let f1Z = -Math.cos(p1.hullRotation);
                        let f2X = -Math.sin(p2.hullRotation); let f2Z = -Math.cos(p2.hullRotation);
                        let t1X = f1X * Math.sign(p1.currentSpeed); let t1Z = f1Z * Math.sign(p1.currentSpeed);
                        let t2X = f2X * Math.sign(p2.currentSpeed); let t2Z = f2Z * Math.sign(p2.currentSpeed);
                        let angleDot = t1X * t2X + t1Z * t2Z;
                        if (p1Ramming && p2Ramming && angleDot < -0.5) {
                            p1.health -= 50; p2.health -= 50;
                            if (p1.health <= 0) p1.die(); if (p2.health <= 0) p2.die();
                            p1.velocity.x += t1X * -1.5; p1.velocity.z += t1Z * -1.5; p1.velocity.y = 0.4;
                            p2.velocity.x += t2X * -1.5; p2.velocity.z += t2Z * -1.5; p2.velocity.y = 0.4;
                            p1.currentSpeed = 0; p2.currentSpeed = 0;
                        } else {
                            let p1RammingP2 = (t1X * -normX + t1Z * -normZ) > 0.5; let p2RammingP1 = (t2X * normX + t2Z * normZ) > 0.5;
                            if (p1Ramming && p1RammingP2 && !p2RammingP1) { p2.die(); p1.currentSpeed *= 0.5; } 
                            else if (p2Ramming && p2RammingP1 && !p1RammingP2) { p1.die(); p2.currentSpeed *= 0.5; } 
                            else { p1.currentSpeed *= 0.3; p2.currentSpeed *= 0.3; p1.velocity.x += normX * 0.5; p1.velocity.z += normZ * 0.5; p2.velocity.x -= normX * 0.5; p2.velocity.z -= normZ * 0.5; }
                        }
                    } else { p1.currentSpeed *= 0.8; p2.currentSpeed *= 0.8; }
                }
            }
        }

        for (let id of tankIds) state.tanks[id] = this.tanks[id].getNetworkState();
        
        state.bullets = this.bullets.map(b => ({
            x: Number(b.x.toFixed(2)), y: Number(b.y.toFixed(2)), z: Number(b.z.toFixed(2)),
            dx: Number(b.dx.toFixed(2)), dy: Number(b.dy.toFixed(2)), dz: Number(b.dz.toFixed(2))
        }));
        
        state.bombs = this.bombs.map(b => ({
            x: Number(b.x.toFixed(1)), y: Number(b.y.toFixed(1)), z: Number(b.z.toFixed(1)),
            vx: Number(b.vx.toFixed(1)), vy: Number(b.vy.toFixed(1)), vz: Number(b.vz.toFixed(1))
        }));
        
        state.explosions = this.explosions;
        state.hits = this.hits; 
        return state;
    }
}

const matches = {};
module.exports = {
    createMatch: (id, configs) => matches[id] = new Match(id, configs),
    deleteMatch: (id) => delete matches[id],
    getMatch: (id) => matches[id],
    getAllMatches: () => matches
};