// environment.js
const MONOLITHS = [
    // 4 Massive Outer Pillars
    { x: 80, z: 80, radius: 8, height: 80 },
    { x: -80, z: 80, radius: 8, height: 80 },
    { x: 80, z: -80, radius: 8, height: 80 },
    { x: -80, z: -80, radius: 8, height: 80 },
    
    // 4 Smaller pillars guarding the ramps of the central plateau
    { x: 35, z: 0, radius: 4, height: 40 },
    { x: -35, z: 0, radius: 4, height: 40 },
    { x: 0, z: 35, radius: 4, height: 40 },
    { x: 0, z: -35, radius: 4, height: 40 }
];

function applyEnvironmentCollisions(tank) {
    for (let m of MONOLITHS) {
        // If the tank somehow jumps over the absolute top of the pillar, ignore collision
        if (tank.position.y > m.height + 2) continue;

        let dx = tank.position.x - m.x;
        let dz = tank.position.z - m.z;
        let dist = Math.hypot(dx, dz);
        
        // Tank hit radius is roughly 3.0
        let minDist = 3.0 + m.radius; 

        // If they crash into the pillar, push them out!
        if (dist < minDist) {
            if (dist === 0) { dx = 1; dz = 0; dist = 1; }
            let push = minDist - dist;
            dx /= dist; dz /= dist;

            // Push tank outside the pillar
            tank.position.x += dx * push;
            tank.position.z += dz * push;

            // Deflect velocity for a realistic "bonk"
            let dot = tank.velocity.x * dx + tank.velocity.z * dz;
            if (dot < 0) {
                tank.velocity.x -= dx * dot * 1.5;
                tank.velocity.z -= dz * dot * 1.5;
            }
            tank.currentSpeed *= 0.8; // Lose speed on crash
        }
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { MONOLITHS, applyEnvironmentCollisions };
} else {
    window.GameEnv = { MONOLITHS };
}