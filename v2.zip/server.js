// server.js
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const nodeDataChannel = require('node-datachannel');
const gameEngine = require('./game-engine');

nodeDataChannel.initLogger("Fatal");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.static('public'));

const activeRooms = new Map();
const activeLobbies = {}; // Lobby state before launching

function genCode() { return Math.random().toString(36).substring(2, 6).toUpperCase(); }
function broadcastLobby(roomCode) { io.to(roomCode).emit('lobby-update', activeLobbies[roomCode]); }

io.on('connection', (socket) => {
    let currentRoom = null;

    socket.on('host-game', () => {
        currentRoom = genCode();
        socket.join(currentRoom);
        activeRooms.set(currentRoom, new Map());
        
        activeLobbies[currentRoom] = {
            host: socket.id,
            slots: {
                'tank1_driver': socket.id, 'tank1_gunner': null,
                'tank2_driver': null, 'tank2_gunner': null
            }
        };
socket.on('send-ping', (data) => {
        if (currentRoom) io.to(currentRoom).emit('receive-ping', data);
    });
        socket.emit('room-joined', { code: currentRoom, isHost: true });
        broadcastLobby(currentRoom);
    });

    socket.on('join-game', (code) => {
        if (activeRooms.has(code) && activeLobbies[code]) {
            currentRoom = code;
            socket.join(currentRoom);
            
            // Find first empty slot
            let assigned = false;
            for (let slot in activeLobbies[code].slots) {
                if (activeLobbies[code].slots[slot] === null) {
                    activeLobbies[code].slots[slot] = socket.id;
                    assigned = true; break;
                }
            }
            if(!assigned) return socket.emit('room-error', 'Room is full!');

            socket.emit('room-joined', { code: currentRoom, isHost: false });
            broadcastLobby(currentRoom);
        } else {
            socket.emit('room-error', 'Invalid Code');
        }
    });

    socket.on('change-slot', (newSlot) => {
        if (!currentRoom || !activeLobbies[currentRoom]) return;
        let lobby = activeLobbies[currentRoom];
        
        if (lobby.slots[newSlot] === null) {
            // Remove from old slot
            for (let s in lobby.slots) { if (lobby.slots[s] === socket.id) lobby.slots[s] = null; }
            // Assign to new slot
            lobby.slots[newSlot] = socket.id;
            broadcastLobby(currentRoom);
        }
    });

    socket.on('start-match', () => {
        if (currentRoom && activeLobbies[currentRoom].host === socket.id) {
            gameEngine.createMatch(currentRoom);
            io.to(currentRoom).emit('launch-game');
        }
    });

    // --- SEAT SWITCHING DURING GAMEPLAY ---
    socket.on('request-seat-swap', () => {
        let match = gameEngine.getMatch(currentRoom);
        if(!match) return;

        let myMapping = match.playerMapping[socket.id];
        if(!myMapping) return;

        let tankId = myMapping.tankId;
        let tank = match.tanks[tankId];

        let otherPlayerId = (myMapping.role === 'driver') ? tank.gunnerId : tank.driverId;

        if (!otherPlayerId) {
            // Tank is empty, swap instantly!
            match.swapSeats(tankId);
        } else {
            // Someone is in the seat, send them a request modal!
            io.to(otherPlayerId).emit('swap-requested', socket.id);
        }
    });

    socket.on('accept-swap', () => {
        let match = gameEngine.getMatch(currentRoom);
        if(match && match.playerMapping[socket.id]) {
            match.swapSeats(match.playerMapping[socket.id].tankId);
        }
    });

    // --- WEBRTC ---
    socket.on('start-webrtc', () => {
        if (!currentRoom) return;
        let pc = new nodeDataChannel.PeerConnection(socket.id, { iceServers: ["stun:stun.l.google.com:19302"] });
        socket.pc = pc;

        pc.onLocalDescription((sdp, type) => socket.emit('webrtc-answer', { sdp, type }));
        pc.onLocalCandidate((candidate, mid) => socket.emit('ice-candidate', { candidate, sdpMid: mid }));

        pc.onDataChannel((dc) => {
            activeRooms.get(currentRoom).set(socket.id, dc);
            
            // Map the player to the physics engine based on lobby choices
            let lobby = activeLobbies[currentRoom];
            for (let slot in lobby.slots) {
                if (lobby.slots[slot] === socket.id) {
                    let parts = slot.split('_'); // 'tank1_driver' -> ['tank1', 'driver']
                    gameEngine.getMatch(currentRoom).assignPlayer(socket.id, parts[0], parts[1]);
                }
            }

            dc.onMessage((msg) => {
                let data = JSON.parse(msg);
                if (data.type === 'input') gameEngine.getMatch(currentRoom).applyInput(socket.id, data.payload);
            });
        });
    });

    socket.on('webrtc-offer', (offer) => { if(socket.pc) socket.pc.setRemoteDescription(offer.sdp, offer.type); });
    socket.on('ice-candidate', (data) => { if(socket.pc) socket.pc.addRemoteCandidate(data.candidate, data.sdpMid); });

    socket.on('disconnect', () => {
        if (currentRoom) {
            if (activeLobbies[currentRoom]) {
                for (let s in activeLobbies[currentRoom].slots) {
                    if (activeLobbies[currentRoom].slots[s] === socket.id) activeLobbies[currentRoom].slots[s] = null;
                }
                broadcastLobby(currentRoom);
            }
            if (activeRooms.has(currentRoom)) {
                activeRooms.get(currentRoom).delete(socket.id);
                let match = gameEngine.getMatch(currentRoom);
                if (match) match.removePlayer(socket.id);

                if (activeRooms.get(currentRoom).size === 0) {
                    activeRooms.delete(currentRoom);
                    delete activeLobbies[currentRoom];
                    gameEngine.deleteMatch(currentRoom);
                }
            }
        }
        if (socket.pc) socket.pc.close();
    });
});

let lastTick = Date.now();
setInterval(() => {
    let now = Date.now();
    let delta = Math.min((now - lastTick) / 1000, 0.1);
    lastTick = now;

    const matches = gameEngine.getAllMatches();
    for (let id in matches) {
        let state = matches[id].tick(delta);
        let stateStr = JSON.stringify({ type: 'state', payload: state });
        let channels = activeRooms.get(id);
        if (channels) channels.forEach(dc => { if (dc.isOpen()) dc.sendMessage(stateStr); });
    }
}, 1000 / 30);

server.listen(3000, () => console.log('🚀 Server running on port 3000'));