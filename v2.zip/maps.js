// maps.js
const MAPS = {
    bowl: {
        getHeight: (x, z) => {
            let dist = Math.hypot(x, z);
            let h = 0;
            
            // 1. Central Plateau (Flat top, smooth ramp down)
            if (dist < 25) {
                h = 12; 
            } else if (dist < 45) {
                let t = (dist - 25) / 20; 
                h = 12 * (0.5 * (1 + Math.cos(t * Math.PI))); // Smooth slope
            }

            // 2. Minor bumpy details on the ground
            h += Math.sin(x * 0.05) * Math.cos(z * 0.05) * 1.5 + Math.sin(x * 0.02 + 1) * Math.cos(z * 0.03 + 2) * 2;

            // 3. Outer Bowl Curve
            if (dist > 120) {
                h += Math.pow(dist - 120, 2) * 0.04;
            }
            
            return h;
        }
    }
};

function getTerrainHeight(x, z) { return MAPS.bowl.getHeight(x, z); }

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { getTerrainHeight };
} else {
    window.GameMaps = { getTerrainHeight };
}