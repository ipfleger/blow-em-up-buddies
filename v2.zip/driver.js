// driver.js
const THREE = require('three');
const { getTerrainHeight } = require('./maps');

const MONOLITHS = [
    { x: 80, z: 80, r: 8, h: 80 }, { x: -80, z: 80, r: 8, h: 80 },
    { x: 80, z: -80, r: 8, h: 80 }, { x: -80, z: -80, r: 8, h: 80 },
    { x: 35, z: 0, r: 4, h: 40 }, { x: -35, z: 0, r: 4, h: 40 },
    { x: 0, z: 35, r: 4, h: 40 }, { x: 0, z: -35, r: 4, h: 40 }
];

const CONFIG = { maxBoost: 100, gravity: -0.015, jumpForce: 0.45, dodgeForce: 0.66 };

class ServerTank {
    constructor(id, colorHex) {
        this.id = id;
        this.colorHex = colorHex;
        
        this.driverId = null; 
        this.gunnerId = null;

        this.position = new THREE.Vector3((Math.random() - 0.5) * 40, 20, (Math.random() - 0.5) * 40);
        this.velocity = new THREE.Vector3(0, 0, 0);

        this.hullRotation = 0; 
        this.currentSpeed = 0;
        this.boost = CONFIG.maxBoost;
        this.health = 100;

        this.turretYaw = 0;
        this.turretPitch = 0;
        
        this.primaryHeat = 0;
        this.isOverheated = false;
        this.bombCooldown = 0;
        this.fireTimer = 0;
        this.fireReady = false; 
        this.bombReady = false; 

        this.isGrounded = false;
        this.canDoubleJump = false;
        this.jumpCooldown = 0;

        this.quaternion = new THREE.Quaternion();
        this.isFlipping = false;
        this.flipAxis = new THREE.Vector3();
        this.flipAngle = 0;
        this.surfaceNormal = new THREE.Vector3(0, 1, 0);

        this.driverInputs = { moveX: 0, moveY: 0, isBoosting: false, triggerJump: false };
        this.gunnerInputs = { aimYaw: 0, aimPitch: 0, isFiring: false, triggerSecondary: false }; 
        
        this.isDead = false;
        this.respawnTimer = 0;
    }

    die() {
        this.isDead = true; this.respawnTimer = 3.0;
        this.position.set(0, -1000, 0); this.velocity.set(0, 0, 0);
        this.currentSpeed = 0; this.isFlipping = false;
    }

    respawn() {
        this.isDead = false;
        this.position.set((Math.random() - 0.5) * 40, 20, (Math.random() - 0.5) * 40);
        this.velocity.set(0, 0, 0); this.currentSpeed = 0;
        this.boost = CONFIG.maxBoost; this.health = 100; this.isGrounded = false;
        this.primaryHeat = 0; this.bombCooldown = 0; this.isOverheated = false;
    }

    update(delta, allTanks) {
        if (this.isDead) {
            this.respawnTimer -= delta;
            if (this.respawnTimer <= 0) this.respawn();
            return;
        }

        // INSTANT ABSOLUTE AIMING SYNC
        this.turretYaw = this.gunnerInputs.aimYaw;
        this.turretPitch = this.gunnerInputs.aimPitch;

        if (this.bombCooldown > 0) this.bombCooldown -= delta;

        if (this.isOverheated) {
            this.primaryHeat -= 40 * delta; 
            if (this.primaryHeat <= 0) { this.primaryHeat = 0; this.isOverheated = false; }
        } else if (!this.gunnerInputs.isFiring) {
            this.primaryHeat = Math.max(0, this.primaryHeat - 20 * delta); 
        }

        this.fireTimer = (this.fireTimer || 0) - delta;
        this.fireReady = false;
        if (this.gunnerInputs.isFiring && !this.isOverheated && this.fireTimer <= 0) {
            this.primaryHeat += 6; 
            if (this.primaryHeat >= 100) { this.primaryHeat = 100; this.isOverheated = true; }
            this.fireTimer = 0.12; 
            this.fireReady = true; 
        }

        this.bombReady = false;
        if (this.gunnerInputs.triggerSecondary && this.bombCooldown <= 0) {
            this.bombCooldown = 3.0; 
            this.bombReady = true; 
        }
        this.gunnerInputs.triggerSecondary = false;

        // --- DRIVER LOGIC ---
        if (this.jumpCooldown > 0) this.jumpCooldown -= delta;

        if (Math.abs(this.driverInputs.moveX) > 0.1) {
            let turnSpeed = this.isGrounded ? 3.0 : 1.8; 
            this.hullRotation -= this.driverInputs.moveX * turnSpeed * delta;
        }

        let dirX = -Math.sin(this.hullRotation);
        let dirZ = -Math.cos(this.hullRotation);
        const rightX = -Math.cos(this.hullRotation);
        const rightZ = Math.sin(this.hullRotation);

        if (this.driverInputs.isBoosting && this.currentSpeed > 50 && this.isGrounded && Math.abs(this.driverInputs.moveX) < 0.1) {
            let bestTarget = null; let smallestAngle = 0.26; 
            for (let otherId in allTanks) {
                if (otherId === this.id) continue;
                let target = allTanks[otherId];
                if (target.isDead) continue;
                let dx = target.position.x - this.position.x; let dz = target.position.z - this.position.z;
                let dist = Math.hypot(dx, dz);
                if (dist > 10 && dist < 80) { 
                    dx /= dist; dz /= dist;
                    let dot = dirX * dx + dirZ * dz;
                    if (dot > Math.cos(smallestAngle)) { smallestAngle = Math.acos(dot); bestTarget = { x: dx, z: dz }; }
                }
            }
            if (bestTarget) {
                let cross = dirX * bestTarget.z - dirZ * bestTarget.x;
                this.hullRotation += (cross > 0 ? -5.0 * delta : 5.0 * delta);
                dirX = -Math.sin(this.hullRotation); dirZ = -Math.cos(this.hullRotation);
            }
        }

        let targetSpeed = 0;
        if (Math.abs(this.driverInputs.moveY) > 0.1) {
            let straightBonus = (Math.abs(this.driverInputs.moveX) < 0.05) ? 1.15 : 1.0;
            targetSpeed = -this.driverInputs.moveY * 40 * straightBonus;
            if (this.driverInputs.isBoosting && this.boost > 0) {
                targetSpeed *= 2.8; this.boost -= 30 * delta; 
            }
        }
        if (!this.driverInputs.isBoosting || Math.abs(this.driverInputs.moveY) < 0.1) {
            this.boost = Math.min(CONFIG.maxBoost, this.boost + 10 * delta); 
        }

        let accelRate = this.driverInputs.isBoosting ? 12 : 8;
        this.currentSpeed += (targetSpeed - this.currentSpeed) * accelRate * delta;

        if (this.driverInputs.triggerJump && this.jumpCooldown <= 0) {
            if (this.isGrounded) {
                this.velocity.y = CONFIG.jumpForce; this.isGrounded = false;
                this.canDoubleJump = true; this.jumpCooldown = 0.15;
            } else if (this.canDoubleJump) {
                this.canDoubleJump = false; this.jumpCooldown = 0.5;
                let mag = Math.hypot(this.driverInputs.moveX, this.driverInputs.moveY);
                if (mag > 0.2) {
                    const normX = this.driverInputs.moveX / mag; const normY = this.driverInputs.moveY / mag;
                    const forwardPropulsion = -normY * 1.75; const sidePropulsion = -normX; 
                    this.velocity.x += (dirX * forwardPropulsion + rightX * sidePropulsion) * CONFIG.dodgeForce;
                    this.velocity.z += (dirZ * forwardPropulsion + rightZ * sidePropulsion) * CONFIG.dodgeForce;
                    this.isFlipping = true; this.flipAngle = 0;
                    this.flipAxis.set(normY, 0, -normX).normalize(); 
                } else {
                    this.velocity.y += CONFIG.jumpForce * 0.8;
                }
            }
            this.driverInputs.triggerJump = false;
        }

        if (!this.isGrounded) {
            this.velocity.y += CONFIG.gravity * 60 * delta;
            this.position.x += this.velocity.x * 60 * delta;
            this.position.z += this.velocity.z * 60 * delta;
            this.surfaceNormal.lerp(new THREE.Vector3(0, 1, 0), 5 * delta).normalize();
        }
        this.position.y += this.velocity.y * 60 * delta;

        let currentGroundY = getTerrainHeight(this.position.x, this.position.z);
        const offset = 2.0;
        const hR = getTerrainHeight(this.position.x + offset, this.position.z);
        const hU = getTerrainHeight(this.position.x, this.position.z + offset);
        this.surfaceNormal.set(currentGroundY - hR, offset, currentGroundY - hU).normalize();

        if (this.isGrounded) {
            if (Math.abs(this.currentSpeed) > 0.1) {
                const forward = new THREE.Vector3(0, 0, -1).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.hullRotation);
                forward.projectOnPlane(this.surfaceNormal).normalize();
                this.position.add(forward.multiplyScalar(this.currentSpeed * delta));
            }
            this.position.x += this.velocity.x * 60 * delta; this.position.z += this.velocity.z * 60 * delta;
            this.velocity.x *= Math.pow(0.01, delta); this.velocity.z *= Math.pow(0.01, delta);
        }

        for (let m of MONOLITHS) {
            if (this.position.y > m.h + 2) continue; 
            let dx = this.position.x - m.x; let dz = this.position.z - m.z;
            let dist = Math.hypot(dx, dz); let minDist = 3.0 + m.r; 
            if (dist < minDist) {
                if (dist === 0) { dx = 1; dz = 0; dist = 1; }
                let push = minDist - dist;
                this.position.x += (dx / dist) * push; this.position.z += (dz / dist) * push;
                let dot = this.velocity.x * (dx/dist) + this.velocity.z * (dz/dist);
                if (dot < 0) {
                    this.velocity.x -= (dx/dist) * dot * 1.5; this.velocity.z -= (dz/dist) * dot * 1.5;
                }
                this.currentSpeed *= 0.5; 
            }
        }

        let newGroundY = getTerrainHeight(this.position.x, this.position.z);
        let stickThreshold = (this.isGrounded && this.velocity.y <= 0) ? 4.0 : 0.5;
        let isSteep = this.surfaceNormal.y < 0.6; 

        if (this.position.y <= newGroundY) {
            this.position.y = newGroundY; 
            if (!isSteep) {
                this.velocity.y = 0;
                this.isGrounded = true; 
                this.canDoubleJump = false; 
                this.isFlipping = false; 
            } else {
                this.velocity.x += this.surfaceNormal.x * 20 * delta;
                this.velocity.z += this.surfaceNormal.z * 20 * delta;
                this.isGrounded = false;
            }
        } else if (this.position.y <= newGroundY + stickThreshold && this.velocity.y <= 0 && !isSteep) {
            this.position.y = newGroundY; 
            this.velocity.y = 0;
            this.isGrounded = true; 
            this.canDoubleJump = false; 
            this.isFlipping = false; 
        } else {
            this.isGrounded = false;
        }

        const tiltQuat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), this.surfaceNormal);
        const yawQuat = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), this.hullRotation);
        const baseQuat = tiltQuat.multiply(yawQuat);

        if (this.isFlipping) {
            this.flipAngle += 15 * delta; 
            if (this.flipAngle >= Math.PI * 2) { this.isFlipping = false; this.flipAngle = 0; }
            const flipQuat = new THREE.Quaternion().setFromAxisAngle(this.flipAxis, this.flipAngle);
            this.quaternion.copy(baseQuat).multiply(flipQuat);
        } else {
            this.quaternion.slerp(baseQuat, 12 * delta); 
        }

        const LIMIT = 190;
        if (this.position.x > LIMIT) { this.position.x = LIMIT; this.velocity.x *= -0.5; this.currentSpeed *= -0.5; }
        if (this.position.x < -LIMIT) { this.position.x = -LIMIT; this.velocity.x *= -0.5; this.currentSpeed *= -0.5; }
        if (this.position.z > LIMIT) { this.position.z = LIMIT; this.velocity.z *= -0.5; this.currentSpeed *= -0.5; }
        if (this.position.z < -LIMIT) { this.position.z = -LIMIT; this.velocity.z *= -0.5; this.currentSpeed *= -0.5; }
    }

    getNetworkState() {
        return {
            x: Number(this.position.x.toFixed(2)), y: Number(this.position.y.toFixed(2)), z: Number(this.position.z.toFixed(2)),
            qx: Number(this.quaternion.x.toFixed(3)), qy: Number(this.quaternion.y.toFixed(3)), qz: Number(this.quaternion.z.toFixed(3)), qw: Number(this.quaternion.w.toFixed(3)),
            rot: Number(this.hullRotation.toFixed(3)), 
            turretYaw: Number(this.turretYaw.toFixed(3)),
            turretPitch: Number(this.turretPitch.toFixed(3)),
            boost: Math.floor(this.boost),
            heat: Number(this.primaryHeat.toFixed(1)),         
            bombCooldown: Number(this.bombCooldown.toFixed(1)),
            isDead: this.isDead,
            isBoosting: this.driverInputs.isBoosting && Math.abs(this.driverInputs.moveY) > 0.1,
            speed: Number(this.currentSpeed.toFixed(1)),
            colorHex: this.colorHex
        };
    }
}

module.exports = { ServerTank };