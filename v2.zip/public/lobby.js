// public/lobby.js

// Initialize the global game socket
window.socket = io();
window.myId = null;
window.currentRoomCode = "----";
window.lobbyState = null;

// The Official Game Color Palette
const PALETTE = ['#b4d455', '#ff3366', '#00ccff', '#ff8c00', '#d44a8e', '#333333', '#1a1a24', '#f0f0f0'];

window.socket.on('connect', () => { window.myId = window.socket.id; });

// Name Validation Helper
function getValidName() {
    const name = document.getElementById('input-name').value.trim().toUpperCase();
    if (name !== 'MAVERICK') {
        alert("Access Denied: Only registered MAVERICKS may pilot these units.");
        return null;
    }
    return name;
}

// UI Buttons
document.getElementById('btn-host').onclick = () => {
    let name = getValidName();
    if (name) window.socket.emit('host-game', name);
};

document.getElementById('btn-join').onclick = () => {
    let name = getValidName();
    if (name) {
        const code = document.getElementById('input-code').value.trim().toUpperCase();
        if (code.length === 4) window.socket.emit('join-game', { code: code, name: name });
    }
};

window.socket.on('room-error', (msg) => alert(msg));

window.socket.on('room-joined', (data) => {
    document.getElementById('start-screen').style.display = 'none';
    document.getElementById('lobby-screen').style.display = 'flex';
    document.getElementById('lobby-code-display').innerText = data.code;
    window.currentRoomCode = data.code;
    
    if (data.isHost) {
        document.getElementById('btn-start-match').style.display = 'block';
        document.getElementById('waiting-msg').style.display = 'none';
    }
});

// Slot Selection Binding
['tank1_driver', 'tank1_gunner', 'tank2_driver', 'tank2_gunner'].forEach(slotId => {
    document.getElementById('slot-' + slotId).onclick = () => {
        window.socket.emit('change-slot', slotId);
    };
});

window.updateLook = function(tank, type, dir) {
    if (!window.lobbyState || !window.lobbyState.custom || !window.lobbyState.custom[tank]) return;
    let val = window.lobbyState.custom[tank][type] + dir;
    if (val > 3) val = 1;
    if (val < 1) val = 3;
    window.socket.emit('update-custom', { tank: tank, type: type, value: val });
};

// Dynamically build Color Swatches
function buildPalettes() {
    ['t1-c1', 't1-c2', 't2-c1', 't2-c2'].forEach(id => {
        const container = document.getElementById('palette-' + id);
        PALETTE.forEach(color => {
            let swatch = document.createElement('div');
            swatch.className = 'swatch';
            swatch.style.background = color;
            swatch.dataset.color = color;
            swatch.onclick = () => {
                let parts = id.split('-'); // ['t1', 'c1']
                let tank = parts[0] === 't1' ? 'tank1' : 'tank2';
                window.socket.emit('update-custom', { tank: tank, type: parts[1], value: color });
            };
            container.appendChild(swatch);
        });
    });
}
buildPalettes();

window.socket.on('lobby-update', (lobby) => {
    window.lobbyState = lobby;
    
    // Reset all buttons to OPEN
    document.querySelectorAll('.slot-btn').forEach(btn => {
        let roleName = btn.id.split('_')[1].toUpperCase();
        btn.innerText = `${roleName}: [ OPEN ]`;
        btn.className = "slot-btn";
    });
    
    // Assign players and display MAVERICK + short ID
    for (let slot in lobby.slots) {
        if (lobby.slots[slot]) {
            let btn = document.getElementById(`slot-${slot}`);
            let roleName = slot.split('_')[1].toUpperCase();
            
            let shortId = lobby.slots[slot].substring(0,4);
            btn.innerText = `${roleName}: MAVERICK [${shortId}]`;
            btn.classList.add(lobby.slots[slot] === window.myId ? 'my-slot' : 'occupied');
        }
    }
    
    // Sync Textures & Palettes
    if (lobby.custom) {
        document.getElementById('t1-body-label').innerText = `BODY ${lobby.custom.tank1.body}`;
        document.getElementById('t1-turret-label').innerText = `TURRET ${lobby.custom.tank1.turret}`;
        document.getElementById('t2-body-label').innerText = `BODY ${lobby.custom.tank2.body}`;
        document.getElementById('t2-turret-label').innerText = `TURRET ${lobby.custom.tank2.turret}`;
        
        ['t1-c1', 't1-c2', 't2-c1', 't2-c2'].forEach(id => {
            let parts = id.split('-');
            let t = parts[0] === 't1' ? 'tank1' : 'tank2';
            let c = parts[1];
            let activeColor = lobby.custom[t][c];
            
            let container = document.getElementById('palette-' + id);
            Array.from(container.children).forEach(sw => {
                if (sw.dataset.color === activeColor) sw.classList.add('selected');
                else sw.classList.remove('selected');
            });
        });
    }
});

document.getElementById('btn-start-match').onclick = () => window.socket.emit('start-match');