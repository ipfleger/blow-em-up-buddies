// public/tank-factory.js

window.TankFactory = {
    
    // Generates a crisp, un-stretched geometric texture
    createCrispTankTexture: function(baseColorHex, accentColorHex) {
        const c = document.createElement('canvas');
        c.width = 256; c.height = 256;
        const ctx = c.getContext('2d');
        
        // Solid Base
        ctx.fillStyle = baseColorHex; 
        ctx.fillRect(0,0,256,256);
        
        // Crisp Blocky Camo/Tech Details
        ctx.fillStyle = accentColorHex;
        ctx.fillRect(0, 0, 64, 64);
        ctx.fillRect(128, 64, 64, 64);
        ctx.fillRect(64, 192, 64, 64);
        
        // Crisp Border outline
        ctx.lineWidth = 8; 
        ctx.strokeStyle = accentColorHex;
        ctx.strokeRect(4, 4, 248, 248);
        
        return new THREE.CanvasTexture(c);
    },

    // Generates the specific Tank Body and Turret combination
    createTank: function(sp, scene) {
        const group = new THREE.Group();
        
        let c1 = sp.c1 || '#b4d455';
        let c2 = sp.c2 || '#333333';
        
        // PRIMARY BODY: Main=C1, Accent=C2
        let bodyTex = this.createCrispTankTexture(c1, c2);
        let bodyMat = new THREE.MeshStandardMaterial({ map: bodyTex, roughness: 0.4, metalness: 0.3 });
        let bodyAccentMat = new THREE.MeshStandardMaterial({ color: c2, roughness: 0.6, metalness: 0.8 });
        
        const bodyGroup = new THREE.Group();
        if (sp.body === 2) { // Sleek Wedge
            let b = new THREE.Mesh(new THREE.BoxGeometry(3.5, 1.2, 5.5), bodyMat);
            let s = new THREE.Mesh(new THREE.BoxGeometry(4.0, 0.5, 1.0), bodyAccentMat);
            s.position.set(0, 0.8, 2.5);
            bodyGroup.add(b, s);
        } else if (sp.body === 3) { // Hovercraft
            let b = new THREE.Mesh(new THREE.CylinderGeometry(2.5, 2.5, 1.5, 10), bodyMat);
            let r = new THREE.Mesh(new THREE.TorusGeometry(2.7, 0.3, 8, 16), bodyAccentMat);
            r.rotation.x = Math.PI/2;
            bodyGroup.add(b, r);
        } else { // Standard Heavy (1)
            let b = new THREE.Mesh(new THREE.BoxGeometry(4, 1.5, 6), bodyMat);
            let t = new THREE.Mesh(new THREE.BoxGeometry(4.8, 1.0, 6.2), bodyAccentMat);
            t.position.y = -0.25;
            bodyGroup.add(b, t);
        }
        bodyGroup.position.y = 1;
        group.add(bodyGroup);
        
        // INVERTED TURRET: Main=C2, Accent=C1
        let turretTex = this.createCrispTankTexture(c2, c1);
        let turMat = new THREE.MeshStandardMaterial({ map: turretTex, roughness: 0.4, metalness: 0.3 });
        let turAccentMat = new THREE.MeshStandardMaterial({ color: c1, roughness: 0.6, metalness: 0.8 });
        
        const turret = new THREE.Group();
        const pitchGroup = new THREE.Group(); 
        
        if (sp.turret === 2) { // Boxy Missile Pod (Twin Barrel)
            let d = new THREE.Mesh(new THREE.BoxGeometry(2.5, 1.2, 2.5), turMat);
            turret.add(d);
            let b1 = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 3.5, 8), turAccentMat);
            b1.rotateX(Math.PI/2); b1.position.set(-0.6, 0, -2);
            let b2 = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 3.5, 8), turAccentMat);
            b2.rotateX(Math.PI/2); b2.position.set(0.6, 0, -2);
            pitchGroup.add(b1, b2);
        } else if (sp.turret === 3) { // Flat Railgun
            let d = new THREE.Mesh(new THREE.BoxGeometry(3, 0.8, 3), turMat);
            turret.add(d);
            let b = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.5, 5), turAccentMat);
            b.position.set(0, 0, -2.5);
            pitchGroup.add(b);
        } else { // Classic Dome (1)
            let d = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 1.2, 8), turMat);
            turret.add(d);
            let b = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 4, 8), turAccentMat);
            b.rotateX(Math.PI/2); b.position.set(0, 0, -2.5);
            pitchGroup.add(b);
        }
        
        turret.add(pitchGroup);
        scene.add(group); 
        scene.add(turret); 
        
        group.turretRef = turret; 
        group.pitchRef = pitchGroup; 
        return group;
    }
};