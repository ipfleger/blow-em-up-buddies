// server.js
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const nodeDataChannel = require('node-datachannel');
const gameEngine = require('./game-engine');
const fs = require('fs');
const path = require('path');


nodeDataChannel.initLogger("Fatal");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.static('public'));

const activeRooms = new Map();
const activeLobbies = {}; // Lobby state before launching

function genCode() { return Math.random().toString(36).substring(2, 6).toUpperCase(); }
function broadcastLobby(roomCode) { io.to(roomCode).emit('lobby-update', activeLobbies[roomCode]); }

// --- LOAD TEAM ICONS ---
let availableIcons = [];
const iconsDir = path.join(__dirname, 'public', 'icons');

// Read the directory safely on server startup
if (fs.existsSync(iconsDir)) {
    availableIcons = fs.readdirSync(iconsDir).filter(file => file.endsWith('.svg'));
}

function getRandomIcons(count) {
    if (availableIcons.length === 0) return [];
    // Shuffle the array and pick the first 'count' elements
    let shuffled = [...availableIcons].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
}
// -----------------------

io.on('connection', (socket) => {
    let currentRoom = null;

socket.on('host-game', (name) => {
        currentRoom = genCode();
        socket.join(currentRoom);
        activeRooms.set(currentRoom, new Map());

        

        // Grab 2 random icons!
        const assignedIcons = getRandomIcons(2);
        
        activeLobbies[currentRoom] = {
            host: socket.id,
            names: { [socket.id]: name }, 
            tankConfigs: {
                tank1: { chassis:0, treads:0, turret:0, barrel:0, c1:'#b4d455', c2:'#ff3366' },
                tank2: { chassis:0, treads:0, turret:0, barrel:0, c1:'#4a8eb3', c2:'#ff8c00' }
            },
            ready: {}, 
            mapVote: {}, 
            icons: {
                team1: assignedIcons[0] || null,
                team2: assignedIcons[1] || null
            },
            slots: {
                'tank1_driver': null, 'tank1_gunner': null,
                'tank2_driver': null, 'tank2_gunner': null
            }
        };

        socket.emit('room-joined', { code: currentRoom, isHost: true });
        broadcastLobby(currentRoom);
    });

    socket.on('join-game', (data) => {
        const code = data.code;
        const name = data.name; // <-- Extract the joining player's name!

        if (activeRooms.has(code) && activeLobbies[code]) {
            currentRoom = code;
            socket.join(currentRoom);
            
            // Store the joining player's name
            activeLobbies[code].names[socket.id] = name; 
            
 
activeLobbies[code].names[socket.id] = name; 
    socket.emit('room-joined', { code: currentRoom, isHost: false });
    broadcastLobby(currentRoom);
        } else {
            socket.emit('room-error', 'Invalid Code');
        }
    });

socket.on('change-slot', (newSlot) => {
        if (!currentRoom || !activeLobbies[currentRoom]) return;
        let lobby = activeLobbies[currentRoom];
        
        // If they click the slot they are ALREADY in, unassign them
        if (lobby.slots[newSlot] === socket.id) {
            lobby.slots[newSlot] = null;
            broadcastLobby(currentRoom);
            return;
        }
        
        // Otherwise, assign them to the new empty slot
        if (lobby.slots[newSlot] === null) {
            for (let s in lobby.slots) { if (lobby.slots[s] === socket.id) lobby.slots[s] = null; }
            lobby.slots[newSlot] = socket.id;
            broadcastLobby(currentRoom);
        }
    });

    socket.on('send-ping', (data) => {
        if (currentRoom) io.to(currentRoom).emit('receive-ping', data);
    });

    socket.on('update-garage', (tankId, role, state) => {
        if(!currentRoom || !activeLobbies[currentRoom]) return;
        let conf = activeLobbies[currentRoom].tankConfigs[tankId];
        
        if (role === 'driver') {
            conf.chassis = state.chassis; conf.treads = state.treads; conf.c1 = state.c1;
        } else {
            conf.turret = state.turret; conf.barrel = state.barrel; conf.c2 = state.c2;
        }
    });

    socket.on('start-match', () => {
        if (currentRoom && activeLobbies[currentRoom].host === socket.id) {
            gameEngine.createMatch(currentRoom, activeLobbies[currentRoom].tankConfigs);
            // CRITICAL FIX: Assign players to their tanks BEFORE launching the game!
            let lobby = activeLobbies[currentRoom];
            for (let slot in lobby.slots) {
                let pId = lobby.slots[slot];
                if (pId) {
                    let parts = slot.split('_'); // 'tank1_driver' -> ['tank1', 'driver']
                    gameEngine.getMatch(currentRoom).assignPlayer(pId, parts[0], parts[1]);
                }
            }
            
            io.to(currentRoom).emit('launch-game');
        }
    });

    // --- SEAT SWITCHING DURING GAMEPLAY ---
    socket.on('request-seat-swap', () => {
        let match = gameEngine.getMatch(currentRoom);
        if(!match) return;

        let myMapping = match.playerMapping[socket.id];
        if(!myMapping) return;

        let tankId = myMapping.tankId;
        let tank = match.tanks[tankId];

        let otherPlayerId = (myMapping.role === 'driver') ? tank.gunnerId : tank.driverId;

        if (!otherPlayerId) {
            // Tank is empty, swap instantly!
            match.swapSeats(tankId);
        } else {
            // Someone is in the seat, send them a request modal!
            io.to(otherPlayerId).emit('swap-requested', socket.id);
        }
    });

    socket.on('accept-swap', () => {
        let match = gameEngine.getMatch(currentRoom);
        if(match && match.playerMapping[socket.id]) {
            match.swapSeats(match.playerMapping[socket.id].tankId);
        }
    });

    // --- WEBRTC ---
    socket.on('start-webrtc', () => {
        if (!currentRoom) return;
        let pc = new nodeDataChannel.PeerConnection(socket.id, { iceServers: ["stun:stun.l.google.com:19302"] });
        socket.pc = pc;

        pc.onLocalDescription((sdp, type) => socket.emit('webrtc-answer', { sdp, type }));
        pc.onLocalCandidate((candidate, mid) => socket.emit('ice-candidate', { candidate, sdpMid: mid }));

        pc.onDataChannel((dc) => {
            activeRooms.get(currentRoom).set(socket.id, dc);

            dc.onMessage((msg) => {
                let data = JSON.parse(msg);
                if (data.type === 'input') gameEngine.getMatch(currentRoom).applyInput(socket.id, data.payload);
            });
        });
    });

    socket.on('webrtc-offer', (offer) => { if(socket.pc) socket.pc.setRemoteDescription(offer.sdp, offer.type); });
    socket.on('ice-candidate', (data) => { if(socket.pc) socket.pc.addRemoteCandidate(data.candidate, data.sdpMid); });

    socket.on('disconnect', () => {
        if (currentRoom) {
            if (activeLobbies[currentRoom]) {
                for (let s in activeLobbies[currentRoom].slots) {
                    if (activeLobbies[currentRoom].slots[s] === socket.id) activeLobbies[currentRoom].slots[s] = null;
                }
                broadcastLobby(currentRoom);
            }
            if (activeRooms.has(currentRoom)) {
                activeRooms.get(currentRoom).delete(socket.id);
                let match = gameEngine.getMatch(currentRoom);
                if (match) match.removePlayer(socket.id);

                if (activeRooms.get(currentRoom).size === 0) {
                    activeRooms.delete(currentRoom);
                    delete activeLobbies[currentRoom];
                    gameEngine.deleteMatch(currentRoom);
                }
            }
        }
        if (socket.pc) socket.pc.close();
    });
});

let lastTick = Date.now();
setInterval(() => {
    let now = Date.now();
    let delta = Math.min((now - lastTick) / 1000, 0.1);
    lastTick = now;

    const matches = gameEngine.getAllMatches();
    for (let id in matches) {
        let state = matches[id].tick(delta);
        let stateStr = JSON.stringify({ type: 'state', payload: state });
        let channels = activeRooms.get(id);
        if (channels) channels.forEach(dc => { if (dc.isOpen()) dc.sendMessage(stateStr); });
    }
}, 1000 / 30);

server.listen(3000, () => console.log('🚀 Server running on port 3000'));