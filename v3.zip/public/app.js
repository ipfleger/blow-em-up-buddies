// public/app.js

document.body.style.userSelect = 'none';
document.body.style.webkitUserSelect = 'none';
document.body.style.webkitTouchCallout = 'none';

const MONOLITHS = [
    { x: 80, z: 80, r: 8, h: 80 }, { x: -80, z: 80, r: 8, h: 80 },
    { x: 80, z: -80, r: 8, h: 80 }, { x: -80, z: -80, r: 8, h: 80 },
    { x: 35, z: 0, r: 4, h: 40 }, { x: -35, z: 0, r: 4, h: 40 },
    { x: 0, z: 35, r: 4, h: 40 }, { x: 0, z: -35, r: 4, h: 40 }
];

const MAX_LOCK_DISTANCE = 150.0;

function getTerrainHeight(x, z) {
    let dist = Math.hypot(x, z); let h = 0;
    if (dist < 25) h = 12; else if (dist < 45) h = 12 * (0.5 * (1 + Math.cos(((dist - 25) / 20) * Math.PI)));
    if (dist > 120) h += Math.pow(dist - 120, 2) * 0.04;
    h += Math.sin(x * 0.05) * Math.cos(z * 0.05) * 1.5;
    return h;
}

const socket = window.socket;
let dataChannel = null; let pc = null;
let hitFlashTimer = 0; 
let isMatchActive = false;

document.getElementById('btn-switch-seat').onclick = () => socket.emit('request-seat-swap');
socket.on('swap-requested', () => document.getElementById('swap-modal').style.display = 'block');
document.getElementById('btn-accept-swap').onclick = () => { socket.emit('accept-swap'); document.getElementById('swap-modal').style.display='none'; };

// --- 1. START THREE.JS IMMEDIATELY ---
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0f0c1b); 
scene.fog = new THREE.FogExp2(0x0f0c1b, 0.015);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);

// CRITICAL FIX: Z-Index ensures canvas is visible!
renderer.domElement.style.position = 'absolute';
renderer.domElement.style.top = '0';
renderer.domElement.style.left = '0';
renderer.domElement.style.zIndex = '1';
document.body.insertBefore(renderer.domElement, document.getElementById('ui-layer'));

const ambientLight = new THREE.AmbientLight(0xffffff, 0.7); scene.add(ambientLight);
const dirLight = new THREE.DirectionalLight(0xffffff, 0.8); dirLight.position.set(50, 100, 50); scene.add(dirLight);

// --- 2. LOBBY SCENE SETUP ---
const lobbyGroup = new THREE.Group();
scene.add(lobbyGroup);

const gridHelper = new THREE.GridHelper(200, 50, 0x6dcbc3, 0x4a8eb3);
lobbyGroup.add(gridHelper);

const previewTanks = { tank1: null, tank2: null };

// Tank 1 (Yours) - Parked front and center
previewTanks.tank1 = window.TankFactory.createTank({id: 'tank1'}, lobbyGroup);
previewTanks.tank1.position.set(0, 0, 0);
previewTanks.tank1.turretRef.position.set(0, 2.2, 0);

// Tank 2 (Enemy/Ally) - Parked in the background
previewTanks.tank2 = window.TankFactory.createTank({id: 'tank2'}, lobbyGroup);
previewTanks.tank2.position.set(-12, 0, -18); // Pushed back and to the left
previewTanks.tank2.turretRef.position.set(-12, 2.2, -18);
previewTanks.tank2.rotation.y = Math.PI / 6; // Angled slightly toward the center
previewTanks.tank2.turretRef.rotation.y = Math.PI / 6;
previewTanks.tank2.visible = true;

// --- 3. BATTLEFIELD SCENE SETUP ---
const matchGroup = new THREE.Group();
matchGroup.visible = false; 
scene.add(matchGroup);

const floorGeo = new THREE.PlaneGeometry(400, 400, 250, 250); floorGeo.rotateX(-Math.PI / 2);
const pos = floorGeo.attributes.position;
for (let i = 0; i < pos.count; i++) { pos.setY(i, getTerrainHeight(pos.getX(i), pos.getZ(i))); }
floorGeo.computeVertexNormals();
const canvas = document.createElement('canvas'); canvas.width = 512; canvas.height = 512;
const ctx = canvas.getContext('2d'); ctx.fillStyle = '#2b3467'; ctx.fillRect(0,0,512,512); ctx.strokeStyle = '#6dcbc3'; ctx.lineWidth = 4; ctx.strokeRect(0,0,512,512);
const tex = new THREE.CanvasTexture(canvas); tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.repeat.set(20, 20); 

const floorMesh = new THREE.Mesh(floorGeo, new THREE.MeshStandardMaterial({ map: tex, flatShading: true }));
floorMesh.userData = { type: 'floor' }; 
matchGroup.add(floorMesh);

function createTechTexture() {
    const c = document.createElement('canvas'); c.width = 512; c.height = 512; const cx = c.getContext('2d');
    cx.fillStyle = '#1a1a24'; cx.fillRect(0,0,512,512); cx.strokeStyle = '#d44a8e'; cx.lineWidth = 3; 
    for(let i=0; i<15; i++) { cx.beginPath(); cx.moveTo(Math.random()*512, 0); cx.lineTo(Math.random()*512, 512); cx.stroke(); }
    cx.strokeStyle = '#6dcbc3'; cx.lineWidth = 6; cx.strokeRect(20, 20, 472, 472); 
    return new THREE.CanvasTexture(c);
}

const monoMat = new THREE.MeshStandardMaterial({ map: createTechTexture(), roughness: 0.2, metalness: 0.6 });
MONOLITHS.forEach(m => {
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(m.r, m.r, m.h, 6), monoMat);
    mesh.position.set(m.x, getTerrainHeight(m.x, m.z) + (m.h / 2) - 2, m.z); 
    mesh.userData = { type: 'obstacle' }; 
    matchGroup.add(mesh);
});

function createFloatingRoomCode(code) {
    const c = document.createElement('canvas'); c.width = 1024; c.height = 256;
    const cx = c.getContext('2d'); cx.fillStyle = 'rgba(0,0,0,0)'; cx.fillRect(0,0,1024,256);
    cx.font = 'bold 200px monospace'; cx.fillStyle = 'rgba(255, 255, 255, 0.15)'; 
    cx.textAlign = 'center'; cx.textBaseline = 'middle'; cx.fillText(`ROOM: ${code}`, 512, 128);
    const plane = new THREE.Mesh(new THREE.PlaneGeometry(200, 50), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(c), transparent: true, side: THREE.DoubleSide }));
    plane.position.set(0, 100, 0); matchGroup.add(plane);
}

// --- 4. LAUNCH LOGIC ---
socket.on('launch-game', () => {
    isMatchActive = true;
    document.getElementById('lobby-screen').style.display = 'none';
    document.getElementById('ui-layer').style.display = 'block';
    document.getElementById('crosshair').style.transition = 'transform 0.1s, background-color 0.1s, border-color 0.1s, border-radius 0.1s';
    
    // Toggle Scenes!
    lobbyGroup.visible = false;
    matchGroup.visible = true;
    scene.background = new THREE.Color(0x1f1c30); 
    scene.fog = null;
    
    createFloatingRoomCode(window.currentRoomCode); 
    socket.emit('start-webrtc');
    initWebRTC();
});

function initWebRTC() {
    pc = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }] });
    dataChannel = pc.createDataChannel("game");
    dataChannel.onmessage = (e) => {
        const data = JSON.parse(e.data);
        if (data.type === 'state') updateGame(data.payload);
    };
    pc.onicecandidate = (e) => { if(e.candidate) socket.emit('ice-candidate', { candidate: e.candidate.candidate, sdpMid: e.candidate.sdpMid }); };
    pc.createOffer().then(o => pc.setLocalDescription(o)).then(() => socket.emit('webrtc-offer', { type: pc.localDescription.type, sdp: pc.localDescription.sdp }));
}


socket.on('webrtc-answer', (answer) => {
    if (pc) pc.setRemoteDescription(new RTCSessionDescription(answer));
});

socket.on('ice-candidate', (data) => {
    if (pc) pc.addIceCandidate(new RTCIceCandidate(data));
});

const activePings = [];
const pingGeo = new THREE.CylinderGeometry(1.5, 1.5, 60, 8);
pingGeo.translate(0, 30, 0); 

function spawnVisualPing(x, y, z, type, ownerId) {
    let color = 0xffffff; 
    if (type === 'enemy') color = 0xff3366; 
    else if (type === 'obstacle') color = 0x00ccff; 

    const material = new THREE.MeshBasicMaterial({ 
        color: color, transparent: true, opacity: 0.6,
        blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false
    });
    
    const pingMesh = new THREE.Mesh(pingGeo, material);
    pingMesh.position.set(x, y, z);
    matchGroup.add(pingMesh); 
    
    activePings.push({ mesh: pingMesh, life: 4.0, type: type, x: x, z: z, owner: ownerId });
}

socket.on('receive-ping', (data) => {
    for (let i = activePings.length - 1; i >= 0; i--) {
        if (activePings[i].owner === data.owner) {
            matchGroup.remove(activePings[i].mesh);
            activePings.splice(i, 1);
        }
    }
    spawnVisualPing(data.x, data.y, data.z, data.type, data.owner);
});

const visualTanks = {};
const activeParticles = []; 
const minimapCtx = document.getElementById('minimap').getContext('2d');

const bulletGeo = new THREE.CylinderGeometry(0.15, 0.15, 6.0, 4); 
bulletGeo.rotateX(Math.PI / 2); 
const bulletMat = new THREE.MeshBasicMaterial({color: 0xffe600});

const bombGeo = new THREE.CylinderGeometry(0.5, 0.5, 2.5, 8); 
bombGeo.rotateX(Math.PI / 2);
const bombMat = new THREE.MeshBasicMaterial({color: 0xff3366});

const bulletPool = []; const bombPool = [];

function emitSparks(tankMesh, rawRot, colorHex, speed) {
    const forward = new THREE.Vector3(0, 0, -1).applyAxisAngle(new THREE.Vector3(0,1,0), rawRot);
    const isReverse = speed < 0; const offsetMult = isReverse ? 2.5 : -2.5; 
    const exhaustPos = tankMesh.position.clone().add(forward.clone().multiplyScalar(offsetMult)); exhaustPos.y += 0.8; 
    const sparkMat = new THREE.MeshBasicMaterial({ color: colorHex });

    for(let i=0; i<2; i++) {
        const spark = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 0.4), sparkMat);
        spark.position.copy(exhaustPos); matchGroup.add(spark);
        const scatter = new THREE.Vector3((Math.random()-0.5)*3, Math.random()*2, (Math.random()-0.5)*3);
        const vel = forward.clone().multiplyScalar(isReverse ? 3 : -3).add(scatter);
        activeParticles.push({ mesh: spark, vel: vel, life: 0.5 });
    }
}

function createShatterParticles(position, count = 40, pColor = 0xff3366) {
    for(let i=0; i<count; i++) {
        const p = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.8, 0.8), new THREE.MeshBasicMaterial({ color: pColor }));
        p.position.copy(position); matchGroup.add(p);
        activeParticles.push({ mesh: p, vel: new THREE.Vector3((Math.random() - 0.5)*8, (Math.random()*6), (Math.random() - 0.5)*8), life: 1.5 });
    }
}

let myCurrentTankId = null;
let myCurrentRole = null;

function updateGame(serverState) {
    let myMapping = serverState.assignments[window.myId];
    if (myMapping) {
        myCurrentTankId = myMapping.tankId;
        myCurrentRole = myMapping.role;
    }

    document.getElementById('crosshair').style.display = (myCurrentRole === 'gunner') ? 'block' : 'none';
    if (myCurrentRole === 'driver') {
        document.getElementById('btn-boost').innerText = 'BOOST';
        document.getElementById('btn-jump').innerText = 'JUMP';
    } else {
        document.getElementById('btn-boost').innerText = 'SHOOT';
        document.getElementById('btn-jump').innerText = 'ROCKET';
    }

    minimapCtx.clearRect(0, 0, 120, 120); minimapCtx.strokeStyle = 'rgba(109, 203, 195, 0.3)';
    minimapCtx.beginPath(); minimapCtx.arc(60, 60, 60, 0, Math.PI*2); minimapCtx.stroke();
    minimapCtx.fillStyle = 'rgba(212, 74, 142, 0.5)';
    MONOLITHS.forEach(m => {
        minimapCtx.beginPath(); minimapCtx.arc(60 + (m.x/200)*60, 60 + (m.z/200)*60, (m.r/200)*60, 0, Math.PI*2); minimapCtx.fill();
    });

    for (let tId in serverState.tanks) {
        let sp = serverState.tanks[tId];
        if (!visualTanks[tId]) { 
	    visualTanks[tId] = window.TankFactory.createTank({id: tId, ...sp.config}, matchGroup); 
            visualTanks[tId].wasDead = false;
            
            visualTanks[tId].traverse(child => { if (child.isMesh) child.userData = { type: 'tank', id: tId }; });
            visualTanks[tId].turretRef.traverse(child => { if (child.isMesh) child.userData = { type: 'tank', id: tId }; });
        }

        if (sp.isDead && !visualTanks[tId].wasDead) {
            createShatterParticles(visualTanks[tId].position);
            visualTanks[tId].turretRef.visible = false;
        }
        visualTanks[tId].wasDead = sp.isDead; visualTanks[tId].visible = !sp.isDead;
        if (!sp.isDead) visualTanks[tId].turretRef.visible = true;

        if (!sp.isDead) {
            let newTargetPos = new THREE.Vector3(sp.x, sp.y, sp.z);
            visualTanks[tId].serverVelocity = visualTanks[tId].lastNetPos ? newTargetPos.clone().sub(visualTanks[tId].lastNetPos).multiplyScalar(30) : new THREE.Vector3(0,0,0);
            visualTanks[tId].lastNetPos = newTargetPos.clone(); visualTanks[tId].targetPos = newTargetPos.clone();  
            visualTanks[tId].targetQuat = new THREE.Quaternion(sp.qx, sp.qy, sp.qz, sp.qw);
            visualTanks[tId].targetRot = sp.rot; 

            if (visualTanks[tId].targetTurretYaw === undefined) {
                visualTanks[tId].targetTurretYaw = sp.turretYaw; 
                visualTanks[tId].targetTurretPitch = sp.turretPitch;
            } 
            else if (!(tId === myCurrentTankId && myCurrentRole === 'gunner')) {
                visualTanks[tId].targetTurretYaw = sp.turretYaw; 
                visualTanks[tId].targetTurretPitch = sp.turretPitch;
            }

            if (visualTanks[tId].position.distanceTo(visualTanks[tId].targetPos) > 15) {
                visualTanks[tId].position.copy(visualTanks[tId].targetPos);
                visualTanks[tId].quaternion.copy(visualTanks[tId].targetQuat);
            }

            if (sp.isBoosting) emitSparks(visualTanks[tId], sp.rot, sp.colorHex, sp.speed);

            minimapCtx.fillStyle = (tId === myCurrentTankId) ? '#b4d455' : '#ff3366';
            minimapCtx.beginPath(); minimapCtx.arc(60 + (sp.x/200)*60, 60 + (sp.z/200)*60, 4, 0, Math.PI*2); minimapCtx.fill();
        }

        if (tId === myCurrentTankId) {
            if (myCurrentRole === 'driver') {
                document.getElementById('bar1-label').innerText = 'BOOST CAPACITY';
                document.getElementById('bar1').style.width = `${Math.max(0, sp.boost)}%`;
                document.getElementById('bar1').style.background = '#b4d455';
                document.getElementById('bar2-container').style.display = 'none';
            } else {
                document.getElementById('bar1-label').innerText = 'WEAPON HEAT';
                document.getElementById('bar1').style.width = `${Math.max(0, sp.heat)}%`;
                document.getElementById('bar1').style.background = sp.heat >= 100 ? '#ff3366' : '#ff8c00';
                
                document.getElementById('bar2-container').style.display = 'block';
                let bombPct = Math.max(0, 100 - (sp.bombCooldown / 3.0) * 100);
                document.getElementById('bar2').style.width = `${bombPct}%`;
                document.getElementById('bar2').style.background = bombPct >= 100 ? '#d44a8e' : '#666';
            }
        }
    }

    for(let i=0; i<bulletPool.length; i++) bulletPool[i].visible = false;
    if (serverState.bullets) {
        for(let i=0; i<serverState.bullets.length; i++) {
            if (!bulletPool[i]) { let m = new THREE.Mesh(bulletGeo, bulletMat); matchGroup.add(m); bulletPool.push(m); }
            let bData = serverState.bullets[i];
            bulletPool[i].position.set(bData.x, bData.y, bData.z);
            bulletPool[i].lookAt(bulletPool[i].position.clone().add(new THREE.Vector3(bData.dx, bData.dy, bData.dz)));
            bulletPool[i].visible = true;
        }
    }

    for(let i=0; i<bombPool.length; i++) bombPool[i].visible = false;
    if (serverState.bombs) {
        for(let i=0; i<serverState.bombs.length; i++) {
            if (!bombPool[i]) { let m = new THREE.Mesh(bombGeo, bombMat); matchGroup.add(m); bombPool.push(m); }
            let bData = serverState.bombs[i];
            bombPool[i].position.set(bData.x, bData.y, bData.z);
            bombPool[i].lookAt(bombPool[i].position.clone().add(new THREE.Vector3(bData.vx, bData.vy, bData.vz)));
            bombPool[i].visible = true;
        }
    }

    if (serverState.explosions) {
        serverState.explosions.forEach(exp => { createShatterParticles(new THREE.Vector3(exp.x, exp.y, exp.z), 40); });
    }

    if (serverState.hits) {
        serverState.hits.forEach(hit => {
            createShatterParticles(new THREE.Vector3(hit.x, hit.y, hit.z), 3, 0xffe600);
            if (hit.owner === myCurrentTankId && myCurrentRole === 'gunner') {
                hitFlashTimer = 0.15;
            }
        });
    }

    for (let p of activePings) {
        let color = '#ffffff'; 
        if (p.type === 'enemy') color = '#ff3366'; 
        if (p.type === 'obstacle') color = '#00ccff'; 
        
        minimapCtx.fillStyle = color;
        minimapCtx.beginPath(); 
        minimapCtx.arc(60 + (p.x/200)*60, 60 + (p.z/200)*60, 3, 0, Math.PI*2); 
        minimapCtx.fill();
    }
}

// --- INPUT STATE ---
let localAim = { yaw: 0, pitch: 0 };
let aimJoystick = { x: 0, y: 0 }; 
const input = { moveX: 0, moveY: 0, aimYaw: 0, aimPitch: 0, isBoosting: false, triggerJump: false, isFiring: false, triggerSecondary: false };

let touchId = null; let startXY = { x: 0, y: 0 };
const joyBase = document.getElementById('joy-base'); const joyNub = document.getElementById('joy-nub');

let lockedTargetId = null; 
let lastTapTime = 0;
let lastTapXY = { x: 0, y: 0 };

function raycastFromScreen(screenX, screenY) {
    const mouse = new THREE.Vector2();
    mouse.x = (screenX / window.innerWidth) * 2 - 1;
    mouse.y = -(screenY / window.innerHeight) * 2 + 1;
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, camera);
    return raycaster.intersectObjects(matchGroup.children, true);
}

document.addEventListener('touchstart', e => {
    if(document.getElementById('start-screen').style.display !== 'none' || document.getElementById('lobby-screen').style.display !== 'none') return;
    
    for(let t of e.changedTouches) {
        const target = document.elementFromPoint(t.clientX, t.clientY);
        if(target && (target.classList.contains('action-button') || target.id === 'btn-switch-seat')) continue;
        
        let now = Date.now();
        let distFromLastTap = Math.hypot(t.clientX - lastTapXY.x, t.clientY - lastTapXY.y);
        
        if (now - lastTapTime < 300 && distFromLastTap < 40) {
            const intersects = raycastFromScreen(t.clientX, t.clientY);
            let hitPoint = null; let hitType = 'floor'; let hitId = null;
            
            for (let i=0; i<intersects.length; i++) {
                let obj = intersects[i].object;
                if (!obj.visible || (obj.parent && !obj.parent.visible)) continue;
                if (obj.userData && obj.userData.type) {
                    if (obj.userData.id === myCurrentTankId) continue;
                    hitPoint = intersects[i].point; hitType = obj.userData.type; hitId = obj.userData.id; 
                    break;
                }
            }
            
            if (hitPoint) {
                if (hitType === 'tank') {
                    if (myCurrentRole === 'gunner' && hitId) {
                        let myT = visualTanks[myCurrentTankId];
                        let targetT = visualTanks[hitId];
                        if (myT && targetT && !targetT.wasDead && myT.position.distanceTo(targetT.position) <= MAX_LOCK_DISTANCE) {
                            lockedTargetId = hitId;
                        }
                    }
                    hitType = 'enemy';
                }
                socket.emit('send-ping', { x: hitPoint.x, y: hitPoint.y, z: hitPoint.z, type: hitType });
            }
            lastTapTime = 0; continue; 
        } 
        lastTapTime = now; lastTapXY = { x: t.clientX, y: t.clientY };
        
        if (t.clientX < window.innerWidth / 2 && touchId === null) {
            touchId = t.identifier; startXY = { x: t.clientX, y: t.clientY };
            joyBase.style.display = 'block'; joyBase.style.left = startXY.x + 'px'; joyBase.style.top = startXY.y + 'px';
        }
    }
}, {passive: false});

document.addEventListener('touchmove', e => {
    if(document.getElementById('start-screen').style.display !== 'none' || document.getElementById('lobby-screen').style.display !== 'none') return;
    e.preventDefault();
    for(let t of e.changedTouches) {
        if (t.identifier === touchId) {
            let dx = t.clientX - startXY.x; let dy = t.clientY - startXY.y;
            let dist = Math.hypot(dx, dy); if(dist > 40) { dx = (dx/dist)*40; dy = (dy/dist)*40; }
            joyNub.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
            
            if (myCurrentRole === 'driver') { input.moveX = dx / 40; input.moveY = dy / 40; } 
            else if (myCurrentRole === 'gunner') { aimJoystick.x = dx / 40; aimJoystick.y = dy / 40; }
        }
    }
}, {passive: false});

const endTouch = e => { 
    for(let t of e.changedTouches) { 
        if(t.identifier === touchId) { 
            touchId = null; joyBase.style.display = 'none'; joyNub.style.transform = 'translate(-50%, -50%)'; 
            input.moveX = 0; input.moveY = 0; aimJoystick.x = 0; aimJoystick.y = 0;
        } 
    } 
};
document.addEventListener('touchend', endTouch); document.addEventListener('touchcancel', endTouch);

document.getElementById('btn-boost').addEventListener('touchstart', (e) => { e.preventDefault(); if(myCurrentRole==='driver') input.isBoosting = true; else input.isFiring = true; });
document.getElementById('btn-boost').addEventListener('touchend', (e) => { e.preventDefault(); input.isBoosting = false; input.isFiring = false; });
document.getElementById('btn-jump').addEventListener('touchstart', (e) => { e.preventDefault(); if(myCurrentRole==='driver') input.triggerJump = true; else input.triggerSecondary = true; });

setInterval(() => { if(dataChannel && dataChannel.readyState === 'open') { dataChannel.send(JSON.stringify({ type: 'input', payload: input })); input.triggerJump = false; input.triggerSecondary = false;} }, 1000/30);

// --- KEYBOARD TESTING CONTROLS ---
const keys = {};

// Track key presses, but ignore them if the user is typing in a text box
window.addEventListener('keydown', e => {
    if (document.activeElement.tagName === 'INPUT') return; 
    keys[e.code] = true;
});
window.addEventListener('keyup', e => keys[e.code] = false);

function processKeyboard() {
    if (!isMatchActive) return; // Don't process game inputs in the lobby

    if (myCurrentRole === 'driver') {
        // W/A/S/D Movement
        if (keys['KeyW']) input.moveY = -1;
        else if (keys['KeyS']) input.moveY = 1;
        else if (!touchId) input.moveY = 0; // Don't override touch if it's active

        if (keys['KeyA']) input.moveX = -1;
        else if (keys['KeyD']) input.moveX = 1;
        else if (!touchId) input.moveX = 0;

        // Shift to Boost, Space to Jump
        if (keys['ShiftLeft'] || keys['ShiftRight']) input.isBoosting = true;
        else if (!touchId) input.isBoosting = false;

        if (keys['Space']) { 
            input.triggerJump = true; 
            keys['Space'] = false; // Force them to release and press again for double jump
        }

    } else if (myCurrentRole === 'gunner') {
        // Arrow Keys for Aiming
        if (keys['ArrowUp']) aimJoystick.y = -1;
        else if (keys['ArrowDown']) aimJoystick.y = 1;
        else if (!touchId) aimJoystick.y = 0;

        if (keys['ArrowLeft']) aimJoystick.x = -1;
        else if (keys['ArrowRight']) aimJoystick.x = 1;
        else if (!touchId) aimJoystick.x = 0;

        // Space to Shoot, Shift for Rocket
        if (keys['Space']) input.isFiring = true;
        else if (!touchId) input.isFiring = false;

        if (keys['ShiftLeft'] || keys['ShiftRight']) { 
            input.triggerSecondary = true; 
            keys['ShiftLeft'] = false; 
            keys['ShiftRight'] = false; 
        }
    }
}

const clock = new THREE.Clock();

function animate() { 
    requestAnimationFrame(animate); 
    const delta = Math.min(clock.getDelta(), 0.1);
    processKeyboard();

    if (!isMatchActive) {
        // --- 5. LOBBY ANIMATION LOOP ---
        const time = Date.now() * 0.0005;
        
        // A gentle, floating sway (Parallax) instead of a full orbit
	camera.position.x = Math.cos(time * 0.5) * 14;
        camera.position.z = Math.sin(time * 0.5) * 14;
        camera.position.y = 4;
        camera.lookAt(0, 1.5, 0);

        if (previewTanks.tank1) {
            previewTanks.tank1.rotation.y = 0;
            // Give the foreground tank a subtle "idle" turret animation
            previewTanks.tank1.turretRef.rotation.y = Math.sin(time * 1.5) * 0.2; 
        }
    } else {
        // --- 6. MATCH ANIMATION LOOP ---
        if (myCurrentRole === 'gunner') {
            if (Math.abs(aimJoystick.x) > 0.01 || Math.abs(aimJoystick.y) > 0.01) {
                lockedTargetId = null; 
                let invertYCheckbox = document.getElementById('invert-y');
                let invertY = invertYCheckbox ? invertYCheckbox.checked : false;
                
                let expX = Math.pow(Math.abs(aimJoystick.x), 2.5) * Math.sign(aimJoystick.x);
                let expY = Math.pow(Math.abs(aimJoystick.y), 2.5) * Math.sign(aimJoystick.y);
                
                localAim.yaw -= expX * 4.5 * delta; 
                localAim.pitch += (invertY ? expY : -expY) * 2.5 * delta;
            }
            
            if (lockedTargetId) {
                let myTank = visualTanks[myCurrentTankId];
                let targetTank = visualTanks[lockedTargetId];
                
                if (!targetTank || targetTank.wasDead || !myTank || myTank.wasDead || myTank.position.distanceTo(targetTank.position) > MAX_LOCK_DISTANCE) {
                    lockedTargetId = null;
                } else {
                    let targetPos = targetTank.position.clone();
                    targetPos.y += 1.5; 
                    let dirToTarget = targetPos.clone().sub(camera.position).normalize();
                    
                    let targetYaw = Math.atan2(-dirToTarget.x, -dirToTarget.z);
                    let targetPitch = Math.asin(dirToTarget.y);
                    let diffYaw = targetYaw - localAim.yaw;
                    while (diffYaw < -Math.PI) diffYaw += Math.PI * 2;
                    while (diffYaw > Math.PI) diffYaw -= Math.PI * 2;

                    localAim.yaw += diffYaw * 12 * delta; 
                    localAim.pitch += (targetPitch - localAim.pitch) * 12 * delta;
                }
            }

            localAim.pitch = Math.max(-Math.PI / 2.05, Math.min(Math.PI / 2.05, localAim.pitch));
            input.aimYaw = localAim.yaw;
            input.aimPitch = localAim.pitch;
        }

        for (let tId in visualTanks) {
            let tank = visualTanks[tId];
            if (tank.targetPos && !tank.wasDead) {
                if (tank.serverVelocity) {
                    tank.targetPos.add(tank.serverVelocity.clone().multiplyScalar(delta));
                    tank.serverVelocity.multiplyScalar(0.85); 
                }
                tank.position.lerp(tank.targetPos, 15 * delta); 
                tank.quaternion.slerp(tank.targetQuat, 15 * delta);

                let visualGroundY = getTerrainHeight(tank.position.x, tank.position.z);
                if (tank.position.y < visualGroundY) tank.position.y = visualGroundY;

                tank.turretRef.position.copy(tank.position);
                tank.turretRef.position.y += 2.2; 

                if (tId === myCurrentTankId && myCurrentRole === 'gunner') {
                    tank.targetTurretYaw = localAim.yaw;
                    tank.targetTurretPitch = localAim.pitch;
                }

                tank.turretRef.rotation.y = THREE.MathUtils.lerp(tank.turretRef.rotation.y, tank.targetTurretYaw || 0, 20 * delta);
                tank.pitchRef.rotation.x = THREE.MathUtils.lerp(tank.pitchRef.rotation.x, (tank.targetTurretPitch || 0), 20 * delta);

                if (tId === myCurrentTankId) {
                    if (myCurrentRole === 'driver') {
                        camera.up.set(0, 1, 0); 
                        const forward = new THREE.Vector3(0, 0, -1).applyAxisAngle(new THREE.Vector3(0,1,0), tank.targetRot || 0);
                        const idealPos = tank.position.clone().add(forward.multiplyScalar(-24));
                        let camGround = getTerrainHeight(idealPos.x, idealPos.z);
                        idealPos.y = Math.max(camGround + 8, tank.position.y + 12);
                        camera.position.lerp(idealPos, 10 * delta);
                        camera.lookAt(tank.position.clone().add(new THREE.Vector3(0, 3, 0)));
                    } else if (myCurrentRole === 'gunner') {
                        camera.up.set(0, 1, 0);
                        let camPos = new THREE.Vector3(tank.turretRef.position.x, tank.turretRef.position.y + 1.2, tank.turretRef.position.z);
                        const aimForward = new THREE.Vector3(0, 0, -1).applyAxisAngle(new THREE.Vector3(0, 1, 0), tank.targetTurretYaw);
                        camPos.add(aimForward.multiplyScalar(1.0)); 
                        camera.position.copy(camPos);
                        camera.rotation.set(tank.targetTurretPitch, tank.targetTurretYaw, 0, 'YXZ');
                    }
                }
            }
        }

        for (let i = activeParticles.length - 1; i >= 0; i--) {
            const pt = activeParticles[i]; 
            pt.vel.y += -0.015 * 60 * delta; 
            pt.mesh.position.addScaledVector(pt.vel, 60 * delta);
            pt.mesh.rotation.x += 0.2; pt.mesh.rotation.y += 0.2; 
            pt.life -= delta;
            if (pt.life > 0) pt.mesh.scale.setScalar(Math.max(0, pt.life * 2));
            else { matchGroup.remove(pt.mesh); activeParticles.splice(i, 1); }
        }

        for (let i = activePings.length - 1; i >= 0; i--) {
            const p = activePings[i];
            p.life -= delta;
            if (p.life <= 0) {
                matchGroup.remove(p.mesh);
                activePings.splice(i, 1);
            } else {
                p.mesh.scale.y = Math.max(0, p.life / 4.0);
            }
        }

        if (myCurrentRole === 'gunner') {
            const crosshair = document.getElementById('crosshair');
            if (hitFlashTimer > 0) {
                hitFlashTimer -= delta;
                crosshair.style.borderColor = 'rgba(255, 255, 255, 0.9)'; 
                crosshair.style.backgroundColor = 'rgba(255, 255, 255, 0.4)';
                crosshair.style.transform = 'translate(-50%, -50%) scale(1.3)';
                crosshair.style.borderRadius = '50%';
            } else {
                if (lockedTargetId) {
                    crosshair.style.borderColor = 'rgba(255, 51, 102, 1.0)'; 
                    crosshair.style.backgroundColor = 'rgba(255, 51, 102, 0.2)';
                    crosshair.style.transform = 'translate(-50%, -50%) scale(0.6) rotate(45deg)'; 
                    crosshair.style.borderRadius = '4px'; 
                } else {
                    crosshair.style.transform = 'translate(-50%, -50%) scale(1.0) rotate(0deg)';
                    crosshair.style.borderRadius = '50%';
                    
                    const raycaster = new THREE.Raycaster();
                    raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
                    const intersects = raycaster.intersectObjects(matchGroup.children, true);
                    
                    let hitObstacle = false;
                    for (let i = 0; i < intersects.length; i++) {
                        let obj = intersects[i].object;
                        if (!obj.visible || (obj.parent && !obj.parent.visible)) continue;
                        if (obj.userData && obj.userData.type === 'obstacle') { hitObstacle = true; break; } 
                        else if (obj.userData && obj.userData.type === 'floor') break;
                    }
                    if (hitObstacle) {
                        crosshair.style.borderColor = 'rgba(255, 140, 0, 0.9)'; 
                        crosshair.style.backgroundColor = 'rgba(255, 140, 0, 0.2)';
                    } else {
                        crosshair.style.borderColor = 'rgba(180, 212, 85, 0.5)'; 
                        crosshair.style.backgroundColor = 'transparent';
                    }
                }
            }
        }
    }
    renderer.render(scene, camera); 
}
// --- GARAGE CUSTOMIZATION LOGIC ---
const PALETTE = ['#b4d455', '#ff3366', '#6dcbc3', '#ff8c00', '#d44a8e', '#ffffff'];
let garageState = { chassis: 0, treads: 0, turret: 0, barrel: 0, pColorIdx: 0, sColorIdx: 1 };

function applyGarageColors() {
    if (!previewTanks.tank1) return;
    
    lobbyGroup.remove(previewTanks.tank1);
    lobbyGroup.remove(previewTanks.tank1.turretRef);

    let c1 = PALETTE[garageState.pColorIdx];
    let c2 = PALETTE[garageState.sColorIdx];

    // Build local preview
    previewTanks.tank1 = window.TankFactory.createTank({
        id: 'tank1', chassis: garageState.chassis, treads: garageState.treads,
        turret: garageState.turret, barrel: garageState.barrel, c1: c1, c2: c2
    }, lobbyGroup);
    
    previewTanks.tank1.position.set(0, 0, 0);
    previewTanks.tank1.turretRef.position.set(0, 2.2, 0);

    // Sync to server!
    if (window.myTankId && window.myRole) {
        window.socket.emit('update-garage', window.myTankId, window.myRole, {
            chassis: garageState.chassis, treads: garageState.treads,
            turret: garageState.turret, barrel: garageState.barrel, c1: c1, c2: c2
        });
    }
}

document.getElementById('btn-color-primary').onclick = () => { garageState.pColorIdx = (garageState.pColorIdx + 1) % PALETTE.length; applyGarageColors(); };
document.getElementById('btn-color-secondary').onclick = () => { garageState.sColorIdx = (garageState.sColorIdx + 1) % PALETTE.length; applyGarageColors(); };

window.cyclePart = function(partType, direction) {
    const options = window.TankFactory.PARTS[partType];
    garageState[partType] = (garageState[partType] + direction + options.length) % options.length;
    document.getElementById(`lbl-${partType}`).innerText = options[garageState[partType]].name;
    applyGarageColors();
};
animate();
